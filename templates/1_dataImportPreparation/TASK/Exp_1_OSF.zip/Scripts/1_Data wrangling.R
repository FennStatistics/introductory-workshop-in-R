##################################################
#### Data Preparation, SIA Non-Decision Time #####
##################################################
# Loading Data -----------------------------------------------------------------
## Loading packages
require(pacman)
p_load('tidyverse', 'xlsx', 'psych', 'data.table', 'plyr', 'jsonlite', 'multiplex', 'rprojroot', 'lsr', 'data.table')
options(scipen=999)


## Set working directory to source file location
myDir = dirname(rstudioapi::getSourceEditorContext()$path)
setwd(myDir)


## Reading in individual datasets and merge all in df, create id column for each participant
data_path <- "../Data/"
output_path <- "../Output/"
dir(data_path)
csvFiles <- list.files(path = data_path, pattern = "study")
dat <- list()

for(i in 1:length(csvFiles)){
  dat[[i]] <- read.csv(paste0(data_path, csvFiles[i]), header=TRUE, na.strings=c("","NA"))
}

df <- as.data.frame(rbindlist(dat, idcol="id", fill=TRUE)) # fill = TRUE because participants with a poor eyesight were asked whether they have corrected their vision

df$outer_counter <- df$outer_counter + 1
df$innerCounter <- df$innerCounter + 1

rm(csvFiles, data_path, i, myDir)


# Response matrix --------------------------------------------------------------
## filter out training trials
df <- df %>% 
  filter(is.na(counterTrain))

## creating total counter variable (per participant)
df$counterTotal <- NA
h <- 1
tmp_counter <- 1
for(i in 1:nrow(df)){
  if(df$id[i] != unique(df$id)[h]){
    tmp_counter <- 1
    h = h + 1
  }
  if(tmp_counter == 1){
    if(df$sender[i] == "fixation" & !is.na(df$sender[i])){
      tmp_counter = tmp_counter + 1
      df$counterTotal[i] <- tmp_counter
    } else{
      df$counterTotal[i] <- tmp_counter
    }
  }else{
    if(df$sender[i] == "Trial" & !is.na(df$sender[i])){
      tmp_counter = tmp_counter + 1
      df$counterTotal[i] <- tmp_counter
    } else{
      df$counterTotal[i] <- tmp_counter
    }
  }
}
df$counterTotal <- df$counterTotal - 1
df$counterTotal[df$counterTotal==1801] <- 0

# fill NA-variables
df <- df %>% 
  group_by(id, counterTotal) %>% 
  fill(c(bright, type, stimuli, correct, correctResponse, innerCounter, response), .direction="updown")  %>% 
  ungroup() %>% 
  group_by(id) %>% 
  fill(instruction, .direction="down") %>% 
  ungroup() %>% 
  group_by(id) %>% 
  fill(c(keyword, keynonword), .direction = "updown") %>% 
  ungroup()

## creating response matrix
resp <- df %>% 
  filter(sender=="stimuli") %>% 
  select(id, counterTotal, stimuli, type, response, duration, correct, correctResponse, bright, instruction, outer_counter, innerCounter, keyword, keynonword)

factors <- c("correctResponse", "bright", "response", "instruction")
resp[,factors] <- lapply(resp[, factors], as.factor)

# writing csv with this output
write.csv(resp, file.path(output_path, "response_matrix.csv", sep=""))
#-------------------------------------------------------------------------------


# Participant matrix -----------------------------------------------------------
N <- length(unique(df$id))

par <- df %>% 
  filter(sender == "Versuchsleitung" | sender == "Demografie" | sender == "Ausschluss") %>% 
  select(id, alter, deutsch_muttersprache, geschlecht, sehschwaeche, sehschwaeche_corrected, student, studienfach, versuchsleitung, keyword, keynonword)

par <- par %>% 
  fill(versuchsleitung, .direction = "down") %>% 
  filter(!is.na(alter))

# writing csv with this output
write.csv(par, file.path(output_path, "participant_matrix.csv", sep=""))
#-------------------------------------------------------------------------------
  
