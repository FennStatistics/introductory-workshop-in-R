##################################################
####  Model Fit, SIA Non-Decision Time  ##########
##################################################
# Loading Data -----------------------------------------------------------------
# Loading packages
require(pacman)
p_load('tidyverse', 'xlsx', 'psych', 'data.table', 'plyr', 'jsonlite', 'multiplex', 'rprojroot', 'lsr', 'data.table', 'scales')
options(scipen=999)


## Set working directory to source file location
myDir = dirname(rstudioapi::getSourceEditorContext()$path)
setwd(myDir)
output_path <- "../Output/"
data_path <- "../Data/fast-dm/"

## Reading in data
resp <- read.csv(paste0(output_path, "resp_dif.csv", sep=""), header=TRUE)
resp <- resp[-1]
df <- read.csv(paste0(data_path, "all_participants_M3a.dat"), sep="", header=TRUE)


# Assessing Model Fit ----------------------------------------------------------
set.seed(123)

## Settings
p <- 5      # precision value
n <- 150   # trial number per dataset
N <- 1      # number of random datasets

# specifying whether parameters depend on conditions
vdepends <- TRUE  
adepends <- TRUE
t0depends <- TRUE
zrdepends <- TRUE
st0depends <- TRUE

# for starting point: if TRUE = relative starting point equals 0.5, i.e., zr = 0.5
fix_zr <- FALSE
# for intertrial variabilities: if TRUE = no intertrialvariability, i.e., sv = 0
fix_sv <- TRUE
fix_szr <- TRUE
fix_st0 <- FALSE

FILE_NAME <- "*.txt"


# Specify conditions here on which parameters depend on (names have to be the same as in dataset from fast-dm, here df)
cond1 <- c("word", "non_word")
cond2 <- c("low", "high")
cond3 <- c("f", "a", "fanda")


# start simulation with construct-samples --------------------------------------
vpn <- df$dataset

for (vp in vpn){
  row_dm <- which(df$dataset==vp)     #participant's row in DM dataset

  for (co1 in cond1){
    for (co2 in cond2){
      for (co3 in cond3){
        
        # drift rate
        if (vdepends == TRUE){
          val_v <- df[row_dm, paste0("v_", co1,"_", co2, sep="")]
        }else{
          val_v <- df[row_dm, "v"]
        }
        
        #boundary
        if (adepends == TRUE){
          val_a <- df[row_dm, paste0("a_", co3, "_", co2, sep="")]
        }else{
          val_a <- df[row_dm, "a"]
        }
        
        # starting point  
        if (fix_zr == TRUE){
          val_zr <- 0.5
        }else{
          if (zrdepends == TRUE){
            val_zr <- df[row_dm, paste0("zr_", co2, sep="")]
          }else{
            val_zr <- df[row_dm, "zr"]
          } }
        
        # non-decision time  
        if (t0depends == TRUE){
          val_t0 <- df[row_dm, paste0("t0_", co2,"_", co3, sep="")]
        }else{
          val_t0 <- df[row_dm, "t0"]
        }
        
        # intertrial variabilities
        if (fix_sv == TRUE){
          val_sv <- 0
        }else{
          val_sv <- df[row_dm, "sv"]
        }  
        
        if (fix_szr == TRUE){
          val_szr <- 0
        }else{
          val_szr <- df[row_dm, "szr"]
        }    
        
        if (fix_st0 == TRUE){
          val_st0 <- 0
        }else{ if (st0depends == TRUE){
          val_st0 <- df[row_dm, paste0("st0_", co2, sep="")]
        }else{
          val_st0 <- df[row_dm, "st0"]
        }
        }
        
        # simulate data based on estimated parameter values usind construct-samples 
        tmp_cmd <-
          paste0("cmd.exe /c", " cd ",find_rstudio_root_file(),"/Output/M3a/Model fit ", "&& construct-samples.exe -a ", val_a, " -z ", val_zr, " -v ", val_v, " -t ",
                 val_t0, " -T ", val_st0, " -Z ", val_szr, " -V ", val_sv, " -p ", p, " -n ", n," -r", " -N ", N, " -o simvp",vp,"_", co1,"_",co2,"_",co3, ".dat", sep = "")
        system(tmp_cmd)  
        print(tmp_cmd)
        
        
      } # end cond3
    } # end cond2
  } # end cond1
} # end vp  

# simulation with construct-samples ended --------------------------------------  

## Read in data from construct-samples
### Reading in words and non-words separately because responses differ
df_sim_list <- list()

for (vp in vpn) {
  file_list <- list.files(
    path = paste0(find_rstudio_root_file(), "/Output/M3a/Model fit"), 
    pattern = paste0("simvp", vp, "_"), 
    full.names = TRUE
  )
  
  df_sim_list[[vp]] <- map_dfr(file_list, ~{
    df <- read.table(.x)
    df$filename <- basename(.x) 
    return(df)
  })
  
  df_sim_list[[vp]]$id <- vp
  
  # Extract word_type ("word" or "non_word")
  df_sim_list[[vp]]$word_type <- ifelse(grepl("_non_word_", df_sim_list[[vp]]$filename), "non_word", "word")
  
  # Extract contrast ("high" or "low")
  df_sim_list[[vp]]$contrast <- ifelse(grepl("_high_", df_sim_list[[vp]]$filename), "high", 
                                       ifelse(grepl("_low_", df_sim_list[[vp]]$filename), "low", NA))
  
  # Extract instructions ("a", "f", or "fanda")
  df_sim_list[[vp]]$instruction <- ifelse(grepl("_a\\.dat$", df_sim_list[[vp]]$filename), "a", 
                                          ifelse(grepl("_f\\.dat$", df_sim_list[[vp]]$filename), "f", 
                                                 ifelse(grepl("_fanda\\.dat$", df_sim_list[[vp]]$filename), "fanda", NA)))
}

df_sim <- ldply(df_sim_list, data.frame)
colnames(df_sim)[1:2] <- c("response", "rt")

df_sim$response_correct <- -99
df_sim$response_correct[df_sim$word_type == "word" & df_sim$response == 1] <- 1
df_sim$response_correct[df_sim$word_type == "non_word" & df_sim$response == 1] <- 0
df_sim$response_correct[df_sim$word_type == "word" & df_sim$response == 0] <- 0
df_sim$response_correct[df_sim$word_type == "non_word" & df_sim$response == 0] <- 1

rm(df_sim_list)

# df_sim as simulated dataset with all participants-----------------------------


# Plotting ---------------------------------------------------------------------
## Preparing datasets  
### Empirical data
df_behav_acc <- resp %>% 
  group_by(id, contrast, instruction) %>% 
  dplyr::summarize(acc_emp = mean(correct)) %>% 
  ungroup()

df_behav_long <- resp %>% 
  group_by(id, contrast, instruction) %>% 
  group_modify(~ {
    quantile(.x$TIME, probs=seq(0,1,.1)) %>% 
      tibble::enframe(name="prob", value="quantile")
  }) %>% 
  ungroup()

df_behav_wide <- pivot_wider(df_behav_long, 
                             names_from = prob,
                             values_from = quantile)

names(df_behav_wide) <- c("id", "contrast", "instruction", paste0("q", seq(0,1,0.1), "emp"))

### Simulated data
df_sim_acc <- df_sim %>% 
  group_by(id, contrast, instruction) %>% 
  dplyr::summarize(acc_sim = mean(response_correct)) %>% 
  ungroup()

df_sim_long <- df_sim %>% 
  group_by(id, contrast, instruction) %>% 
  group_modify(~ {
    quantile(.x$rt, probs=seq(0,1,.1)) %>% 
      tibble::enframe(name="prob", value="quantile")
  }) %>% 
  ungroup()

df_sim_wide <- pivot_wider(df_sim_long, 
                           names_from = prob,
                           values_from = quantile)

names(df_sim_wide) <- c("id", "contrast", "instruction", paste0("q", seq(0,1,0.1), "sim"))


df_plot_rt <- as.data.frame(merge(df_behav_wide, df_sim_wide, by=c("id", "contrast", "instruction")))
df_plot_acc <- as.data.frame(merge(df_behav_acc, df_sim_acc, by=c("id","contrast", "instruction")))

## Specifying ranges for plots
min_acc <- 0.5
max_acc <- 1
max_rt <- 1.5
min_rt <- 0.2

## Creating accuracy plot per condition
pdf(file=paste0(find_rstudio_root_file(), "/Output/M3a/Model fit/M3a_model_fit_by_condition.pdf"))
par(mfrow=c(3,2), mar=c(4,4,2,1))  

# different colors for different instructions
colors <- c("#1B9E77", "#D95F02", "#7570B3")  
names(colors) <- c("a", "f", "fanda")
instruction_labels <- c("a" = "accurate", "f" = "fast", "fanda" = "fast/accurate")

# First Plot: Accuracy + both legends
plot(df_plot_acc$acc_emp, df_plot_acc$acc_sim, 
     xlim=c(min_acc, max_acc), ylim=c(min_acc, max_acc), 
     xlab="Empirical", ylab="Predicted", las=1, 
     main="Accuracy", 
     pch=as.numeric(as.factor(df_plot_acc$contrast)), 
     col=colors[df_plot_acc$instruction])
segments(0, 0, 1, 1)

legend("topright", 
       legend = unique(df_plot_acc$contrast),  
       pch = unique(as.numeric(as.factor(df_plot_acc$contrast))),  
       col = "black",  
       title = "Contrast", 
       bty = "n", 
       inset = c(0.52, 0))  

legend("topleft", 
       legend = instruction_labels,  
       col = colors,  
       pch = 15,  
       title = "Instruction",  
       bty = "n")

# RT Plots
qu_texts <- c("0.1", "0.3", "0.5", "0.7", "0.9")
qus_emp <- paste0("q", qu_texts, "emp")
qus_sim <- paste0("q", qu_texts, "sim")


for (qu_nr in seq_along(qus_emp)) {
  qu_emp <- qus_emp[qu_nr]
  qu_sim <- qus_sim[qu_nr]
  qu_text <- qu_texts[qu_nr]
  
  plot(df_plot_rt[[qu_emp]], df_plot_rt[[qu_sim]], 
       xlim=c(0, max_rt), ylim=c(0, max_rt), 
       xlab="Empirical", ylab="Predicted", 
       main=paste("RT (s) - ", qu_text, " quantile"), 
       las=1, 
       pch=as.numeric(as.factor(df_plot_rt$contrast)), 
       col=colors[df_plot_rt$instruction])
  segments(0, 0, max_rt, max_rt)
}

dev.off()


# ------------------------------------------------------------------------------
