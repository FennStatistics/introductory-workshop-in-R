##################################################
#############  Model comparison  #################
##################################################
# Loading Data -----------------------------------------------------------------
# Loading packages
require(pacman)
p_load('effectsize', 'tidyverse','jtools', 'xlsx', 'psych', 'data.table', 'plyr', 'jsonlite', 'multiplex', 'rprojroot', 'lsr', 'data.table', 'scales', 'ggstatsplot', 'ggpubr')
options(scipen=999)


## Set working directory to source file location
myDir = dirname(rstudioapi::getSourceEditorContext()$path)
setwd(myDir)
output_path <- "../Output/"
data_path <- "../Data/fast-dm/"

## Reading in response data
resp <- read.csv(paste0(output_path, "resp_matrix_excl.csv", sep=""), header=TRUE)
resp <- resp[,-1]

par_n <- resp %>% 
  dplyr::group_by(id) %>% 
  dplyr::summarise(
    trials = n(),
  ) %>% ungroup() %>% 
  dplyr::rename(., dataset = id)


## Reading in data (all ML models)
# Models in main manuscript
ml1 <- read.csv(paste0(data_path, "all_participants_M1a.dat"), sep="", header=TRUE)
ml2 <- read.csv(paste0(data_path, "all_participants_M2a.dat"), sep="", header=TRUE)
ml3 <- read.csv(paste0(data_path, "all_participants_M3a.dat"), sep="", header=TRUE)
ml4 <- read.csv(paste0(data_path, "all_participants_M4a.dat"), sep="", header=TRUE)

m1 <- merge(ml1, par_n, by="dataset")
m2 <- merge(ml2, par_n, by="dataset")
m3 <- merge(ml3, par_n, by="dataset")
m4 <- merge(ml4, par_n, by="dataset")

# Models in SOM
ml5 <- read.csv(paste0(data_path, "all_participants_M5.dat"), sep="", header=TRUE)
ml6 <- read.csv(paste0(data_path, "all_participants_M6.dat"), sep="", header=TRUE)
ml7 <- read.csv(paste0(data_path, "all_participants_M7.dat"), sep="", header=TRUE)
ml8 <- read.csv(paste0(data_path, "all_participants_M8.dat"), sep="", header=TRUE)

m5 <- merge(ml5, par_n, by="dataset")
m6 <- merge(ml6, par_n, by="dataset")
m7 <- merge(ml7, par_n, by="dataset")
m8 <- merge(ml8, par_n, by="dataset")


# Calculating BIC 
## BIC = -2LL + ln(n) * k
## n = number of observations (trials)
## k = number of free parameters
## fit column in fast-dm output = -LL

k <- 8 # number of models to compare
BIC <- matrix(NA, nrow = length(ml1$dataset), ncol = k)
colnames(BIC) <- c("m1", "m2", "m3", "m4", "m5", "m6", "m7", "m8")
i <- 1
for (i in 1:length(ml1$dataset)){
    BIC[i, 1] = 2*m1$fit[i] + 19 * log(m1$trials[i])
    BIC[i, 2] = 2*m2$fit[i] + 27 * log(m2$trials[i])
    BIC[i, 3] = 2*m3$fit[i] + 20 * log(m3$trials[i])
    BIC[i, 4] = 2*m4$fit[i] + 24 * log(m4$trials[i])

    BIC[i, 5] = 2*m5$fit[i] + 21 * log(m5$trials[i])
    BIC[i, 6] = 2*m6$fit[i] + 18 * log(m6$trials[i])
    BIC[i, 7] = 2*m7$fit[i] + 16 * log(m7$trials[i])
    BIC[i, 8] = 2*m8$fit[i] + 15 * log(m8$trials[i])
}

sort(round(colSums(BIC)))
table(apply(BIC, 1, which.min)) #for how many participants is which model best?


# Calculating AIC 
## AIC = -2LL + 2 * k
## k = number of free parameters
## fit column in fast-dm output = -LL

AIC = cbind(
  m1 = 2*m1$fit + 2 * 19,
  m2 = 2*m2$fit + 2 * 27,
  m3 = 2*m3$fit + 2 * 20,
  m4 = 2*m4$fit + 2 * 24,
  
  m5 = 2*m5$fit + 2 * 21,
  m6 = 2*m6$fit + 2 * 18,
  m7 = 2*m7$fit + 2 * 16,
  m8 = 2*m8$fit + 2 * 15
)

sort(round(colSums(AIC)))
table(apply(AIC, 1, which.min)) #for how many participants is which model best?
