##################################################
####  Model analysis, SIA Non-Decision Time  #####
##################################################
# Loading Data -----------------------------------------------------------------
# Loading packages
require(pacman)
p_load('tidyverse', 'xlsx', 'psych', 'data.table', 'plyr', 'jsonlite', 'multiplex', 'rprojroot', 'lsr', 'data.table', 'scales', 'ggstatsplot', 'ggpubr')
options(scipen=999)


## Set working directory to source file location
myDir = dirname(rstudioapi::getSourceEditorContext()$path)
setwd(myDir)
output_path <- "../Output/"
data_path <- "../Data/fast-dm/"

## Reading in data
resp <- read.csv(paste0(output_path, "resp_dif.csv", sep=""), header=TRUE)
resp <- resp[-1]
df <- read.csv(paste0(data_path, "all_participants_M3c.dat"), sep="", header=TRUE)


# Descriptives about model parameters ------------------------------------------
df %>% 
  select(v_non_word_low, v_non_word_high, v_word_low, v_word_high,
         a_f_low, a_f_high, a_a_low, a_a_high, a_fanda_low, a_fanda_high, 
         zr_low, zr_high, 
         t0_low_f,t0_high_f, t0_low_a, t0_high_a, t0_low_fanda, t0_high_fanda,
         st0_low, st0_high) %>% 
  describe()


# Summarizing effect sizes
effect_sizes_f <- df %>%
  mutate(dz_t0_f = cohens_d(t0_low_f, t0_high_f, paired = T)$Cohens_d,
         dz_v_words = cohens_d(v_word_low, v_word_high, paired = T)$Cohens_d,
         dz_v_non_words = cohens_d(v_non_word_low, v_non_word_high, paired = T)$Cohens_d,
         dz_a_f = cohens_d(a_f_low, a_f_high, paired = T)$Cohens_d,
         dz_zr = cohens_d(zr_low, zr_high, paired = T)$Cohens_d,
         dz_st0 = cohens_d(st0_low, st0_high, paired = T)$Cohens_d,
  ) %>% 
  select(dz_t0_f:dz_st0) %>% 
  filter(row_number()==1) %>% 
  pivot_longer(
    cols = c(dz_t0_f:dz_st0),
    names_to = "condition",
    values_to = "dz"
  )


effect_sizes_a <- df %>%
  mutate(dz_t0_a = cohens_d(t0_low_a, t0_high_a, paired = T)$Cohens_d,
         dz_v_words = cohens_d(v_word_low, v_word_high, paired = T)$Cohens_d,
         dz_v_non_words = cohens_d(v_non_word_low, v_non_word_high, paired = T)$Cohens_d,
         dz_a_a = cohens_d(a_a_low, a_a_high, paired = T)$Cohens_d,
         dz_zr = cohens_d(zr_low, zr_high, paired = T)$Cohens_d,
         dz_st0 = cohens_d(st0_low, st0_high, paired = T)$Cohens_d,
  ) %>% 
  select(dz_t0_a:dz_st0) %>% 
  filter(row_number()==1) %>% 
  pivot_longer(
    cols = c(dz_t0_a:dz_st0),
    names_to = "condition",
    values_to = "dz"
  )

effect_sizes_fanda <- df %>%
  mutate(dz_t0_fanda = cohens_d(t0_low_fanda, t0_high_fanda, paired = T)$Cohens_d,
         dz_v_words = cohens_d(v_word_low, v_word_high, paired = T)$Cohens_d,
         dz_v_non_words = cohens_d(v_non_word_low, v_non_word_high, paired = T)$Cohens_d,
         dz_a_fanda = cohens_d(a_fanda_low, a_fanda_high, paired = T)$Cohens_d,
         dz_zr = cohens_d(zr_low, zr_high, paired = T)$Cohens_d,
         dz_st0 = cohens_d(st0_low, st0_high, paired = T)$Cohens_d,
  ) %>% 
  select(dz_t0_fanda:dz_st0) %>% 
  filter(row_number()==1) %>% 
  pivot_longer(
    cols = c(dz_t0_fanda:dz_st0),
    names_to = "condition",
    values_to = "dz"
  )


# creating long format
df_long <- df %>% 
  pivot_longer(
    cols = contains(c("high", "low")),
    names_to = "condition",
    values_to = "parameter_value"
  )

df_long$contrast <- -99
df_long$contrast[grepl("high", df_long$condition)] <- "high"
df_long$contrast[grepl("low", df_long$condition)] <- "low"

df_long$param <- str_sub(df_long$condition, start= 1, end= 2)
df_long$param[df_long$param=="a_"] <- "a"
df_long$param[df_long$condition == "v_non_word_high" | df_long$condition == "v_non_word_low" ] <- "v_non_word"
df_long$param[df_long$condition == "v_word_high" | df_long$condition == "v_word_low"] <- "v_word"


df_long$inst <- "fixed between instructions"
df_long$inst[grepl("_f", df_long$condition)] <- "fast"
df_long$inst[grepl("_fanda", df_long$condition)] <- "fast and accurate"
df_long$inst[grepl("_a", df_long$condition)] <- "accurate"


# Analyzing model parameters ---------------------------------------------------
# Calculating t-tests
## Drift rate
### Non-words
boxplot(df[, c("v_non_word_low", "v_non_word_high")])
t.test(df$v_non_word_low, df$v_non_word_high, paired=T)
v_non_word_d <- cohensD(df$v_non_word_low, df$v_non_word_high, method="paired")

### Words
boxplot(df[, c("v_word_low", "v_word_high")])
t.test(df$v_word_low, df$v_word_high, paired=T)
v_word_d <- cohensD(df$v_word_low, df$v_word_high, method="paired")

## Threshold
### Fast condition
boxplot(df[, c("a_f_low", "a_f_high")])
t.test(df$a_f_low, df$a_f_high, paired=T)
a_f_d <- cohensD(df$a_f_low, df$a_f_high, method="paired")

### Accurate condition
boxplot(df[, c("a_a_low", "a_a_high")])
t.test(df$a_a_low, df$a_a_high, paired=T)
a_a_d <- cohensD(df$a_a_low, df$a_a_high, method="paired")

### Fast and accurate condition
boxplot(df[, c("a_fanda_low", "a_fanda_high")])
t.test(df$a_fanda_low, df$a_fanda_high, paired=T)
a_fanda_d <- cohensD(df$a_fanda_low, df$a_fanda_high, method="paired")

## Starting point
boxplot(df[, c("zr_low", "zr_high")])
t.test(df$zr_low, df$zr_high, paired=T)
zr_d <- cohensD(df$zr_low, df$zr_high, method="paired")

## Non-decision time
### Fast condition
boxplot(df[, c("t0_low_f", "t0_high_f")])
t.test(df$t0_low_f, df$t0_high_f, paired=T)
t0_low_d <- cohensD(df$t0_low_f, df$t0_high_f, method="paired")

### Accurate condition
boxplot(df[, c("t0_low_a", "t0_high_a")])
t.test(df$t0_low_a, df$t0_high_a, paired=T)
t0_a_d <- cohensD(df$t0_low_a, df$t0_high_a, method="paired")

### Fast and accurate condition
boxplot(df[, c("zr_low", "zr_high")])
t.test(df$t0_low_fanda, df$t0_high_fanda, paired=T)
t0_fanda_d <- cohensD(df$t0_low_fanda, df$t0_high_fanda, method="paired")

## Intertrial variability of non-decision time
boxplot(df[, c("st0_low", "st0_high")])
t.test(df$st0_low, df$st0_high, paired=T)
st0_d <- cohensD(df$st0_low, df$st0_high, method="paired")


# Visualization ----------------------------------------------------------------
p <- ggpaired(df_long, x = "contrast", y = "parameter_value", id="dataset",
              xlab = "contrast", ylab = "parameter value",
              color = "contrast", palette = "jco", 
              line.color = "gray", line.size = 0.4,
              facet.by=c("param", "inst"), scales="free")
p_fin <- p + stat_compare_means(method = "t.test", label = "p.format", paired = TRUE) +
  theme(legend.position = "none")

p_fin

ggsave(path = output_path, filename = "M1b.jpeg", width = 20, height = 18)


# Plot for Manuscript
df_long_plot <- df_long
df_long_plot$inst <- factor(df_long_plot$inst,
                            levels = c("accurate", "fast", "fast and accurate", "fixed between instructions"),
                            labels = c("a", "f", "f/a", "fixed"))

df_long_plot$param <- factor(df_long$param, 
                             levels = c("t0", "v_word", "v_non_word", "a", "zr", "st"),
                             labels = c("t[0]", "v[word]", "v[non_word]", "a", "z[r]", "s[t0]"))

plot_f <- df_long_plot %>% 
  filter(inst=="fixed"|inst=="f")

plot_a <- df_long_plot %>% 
  filter(inst=="fixed"|inst=="a")

plot_fa <- df_long_plot %>% 
  filter(inst=="fixed"|inst=="f/a")


effect_sizes_f$label <- paste0("d"," = ", round(effect_sizes_f$dz, 2))
effect_sizes_f$param <- factor(effect_sizes_f$condition, 
                               levels = c("dz_t0_f", "dz_v_words", "dz_v_non_words", "dz_a_f", "dz_zr", "dz_st0"),
                               labels = c("t[0]", "v[word]", "v[non_word]", "a", "z[r]", "s[t0]"))

effect_sizes_a$label <- paste0("d"," = ", round(effect_sizes_a$dz, 2))
effect_sizes_a$param <- factor(effect_sizes_a$condition, 
                               levels = c("dz_t0_a", "dz_v_words", "dz_v_non_words", "dz_a_a", "dz_zr", "dz_st0"),
                               labels = c("t[0]", "v[word]", "v[non_word]", "a", "z[r]", "s[t0]"))

effect_sizes_fanda$label <- paste0("d"," = ", round(effect_sizes_fanda$dz, 2))
effect_sizes_fanda$param <- factor(effect_sizes_fanda$condition, 
                                   levels = c("dz_t0_fanda", "dz_v_words", "dz_v_non_words", "dz_a_fanda", "dz_zr", "dz_st0"),
                                   labels = c("t[0]", "v[word]", "v[non_word]", "a", "z[r]", "s[t0]"))



f <- ggplot(plot_f, aes(x = contrast, y = parameter_value)) + 
  geom_boxplot()+
  geom_line(aes(group=dataset), colour="gray", linetype = "dotted")+
  facet_wrap(~param, scales = "free_y",
             labeller = label_parsed) +
  labs(y = "Parameter value", x = "Contrast condition")+
  theme_apa(x.font.size = 18, y.font.size = 18, facet.title.size = 20)+
  theme(axis.text = element_text(size = 16))+
  geom_text(data = effect_sizes_f, aes(x = Inf, y = -Inf, label = label), 
            hjust = 1, vjust = -1, size = 6, color = "black", check_overlap = TRUE)

f
ggsave("plot_f.jpeg", path = paste0(output_path, "M3c"), plot=f, width = 13, height = 8)

a <- ggplot(plot_a, aes(x = contrast, y = parameter_value)) + 
  geom_boxplot()+
  geom_line(aes(group=dataset), colour="gray", linetype = "dotted")+
  facet_wrap(~param, scales = "free_y",
             labeller = label_parsed) +
  labs(y = "Parameter value", x = "Contrast condition")+
  theme_apa(x.font.size = 18, y.font.size = 18, facet.title.size = 20)+
  theme(axis.text = element_text(size = 16))+
  geom_text(data = effect_sizes_a, aes(x = Inf, y = -Inf, label = label), 
            hjust = 1, vjust = -1, size = 6, color = "black", check_overlap = TRUE)
a
ggsave("plot_a.jpeg", path = paste0(output_path, "M3c"), plot=a, width = 13, height = 8)

fa <- ggplot(plot_fa, aes(x = contrast, y = parameter_value)) + 
  geom_boxplot()+
  geom_line(aes(group=dataset), colour="gray", linetype = "dotted")+
  facet_wrap(~param, scales = "free_y",
             labeller = label_parsed) +
  labs(y = "Parameter value", x = "Contrast condition")+
  theme_apa(x.font.size = 18, y.font.size = 18, facet.title.size = 20)+
  theme(axis.text = element_text(size = 16))+
  geom_text(data = effect_sizes_fanda, aes(x = Inf, y = -Inf, label = label), 
            hjust = 1, vjust = -1, size = 6, color = "black", check_overlap = TRUE)
fa
ggsave("plot_fa.jpeg", path = paste0(output_path, "M3c"), plot=fa, width = 13, height = 8)
