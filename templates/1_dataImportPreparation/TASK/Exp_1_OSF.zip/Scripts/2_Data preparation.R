##################################################
#### Data Preparation, SIA Non-Decision Time #####
##################################################
# Loading Data -----------------------------------------------------------------
# Loading packages
require(pacman)
p_load('tidyverse', 'xlsx', 'psych', 'data.table', 'plyr', 'jsonlite', 'multiplex', 'rprojroot', 'lsr', 'data.table')
options(scipen=999)


## Set working directory to source file location
myDir = dirname(rstudioapi::getSourceEditorContext()$path)
setwd(myDir)
output_path <- "../Output/"

## Reading in data
### response matrix
resp <- read.csv(paste0(output_path, "response_matrix.csv", sep=""), header=TRUE)
resp <- resp[,-1]

resp$correct <- as.logical(resp$correct)
factors <- c("correctResponse", "bright", "response", "instruction")
resp[,factors] <- lapply(resp[, factors], as.factor)

# Data inspection --------------------------------------------------------------
## graphically
### Plotting histogram per participant
for(i in unique(resp$id)) {
  tmp <- resp %>% filter(id==i)
  print(ggplot(data=tmp, aes(x=duration, color=bright)) + 
          geom_histogram(binwidth = 40, position="identity", alpha=0.4) +
          geom_vline(aes(xintercept=mean(duration, na.rm=T)))+
          labs(title = paste("Participant ", i)))
}  

### Plotting RTs per participant over time, facetted by accuracy
for(i in unique(resp$id)) {
  tmp <- resp %>% filter(id==i)
  print(ggplot(data=tmp, aes(x=counterTotal, y=duration, fill=correct)) + 
          geom_col() + 
          labs(title = paste("Participant ", i)))
} 


## descriptively
trials <- resp %>% 
  dplyr::group_by(id, bright) %>% 
  tally() %>% ungroup()

sum_stats_participant <- resp %>% 
  dplyr::group_by(id, bright) %>% 
  dplyr::summarise(
    trials = n(),
    mean_rt = mean(duration, na.rm=T),
    mean_rt_correct = mean(duration[correct==TRUE], na.rm=T),
    mean_acc = mean(correct, na.rm=T)
  ) %>% ungroup()

mean(sum_stats_participant$mean_rt[sum_stats_participant$bright=="rgb(15,15,15)"], na.rm = T)
mean(sum_stats_participant$mean_rt[sum_stats_participant$bright=="rgb(255, 255, 255)"], na.rm = T)

mean(sum_stats_participant$mean_acc[sum_stats_participant$bright=="rgb(15,15,15)"], na.rm = T)
mean(sum_stats_participant$mean_acc[sum_stats_participant$bright=="rgb(255, 255, 255)"], na.rm = T)

#-------------------------------------------------------------------------------


# Outlier Detection ------------------------------------------------------------
## on participant level with absolute values
sum_stats_participant <- sum_stats_participant %>% 
  mutate(outlier = case_when(mean_rt <= 350 ~ TRUE,
                             mean_rt >= 1500 ~ TRUE,
                             mean_acc <= 0.5 ~ TRUE,
                             TRUE ~ FALSE)) #oder Verknüpfung

sum(sum_stats_participant$outlier) # number of participant outliers
outlier <- sum_stats_participant$id[sum_stats_participant$outlier == "TRUE"]

resp <- resp[!resp$id %in% outlier,] # excluding outliers from df in long format

## on trial level with absolute values
# Excluding
resp_excl <- resp %>% 
  filter(duration >= 300 & duration <= 2500)


# trials that got excluded overall
excl <- nrow(resp) - nrow(resp_excl) # absolute
(excl/nrow(resp))*100 # relative in percent

# trials that got excluded per participant
trials_excl <- resp_excl %>%
  group_by(id) %>% 
  dplyr::summarise(trials_analyses=n()) %>%
  ungroup() %>% 
  mutate(exclusions = 1800-trials_analyses)


## Plotting histogram again to check distributions
for(i in unique(resp_excl$id)) {
  tmp <- resp_excl %>% filter(id==i)
  print(ggplot(data=tmp, aes(x=duration, color=correct)) + 
          geom_histogram(binwidth = 40, position="identity", alpha=0.4) +
          geom_vline(aes(xintercept=mean(duration, na.rm=T)))+
          labs(title = paste("Participant ", i))+ 
          theme_bw())
}  

#-------------------------------------------------------------------------------

# Graphical Inspection ---------------------------------------------------------
## Split-violin plots per participant
# Reaction time ranges
min <- round(min(resp_excl$duration), -2) - 100
max <- round(max(resp_excl$duration), -2) + 100

i <- 1
for(i in unique(resp_excl$id)) {
  tmp <- resp_excl %>% filter(id==i)
  print(ggplot(tmp, aes(x=bright, y=duration, fill=correct)) +
          introdataviz::geom_split_violin(alpha = .4) +
          geom_boxplot(width = .2, alpha = .6, show.legend = FALSE) +
          stat_summary(fun.data = "mean_se", geom = "pointrange", show.legend = F, 
                       position = position_dodge(.175)) +
          scale_x_discrete(name = "Brightness") +
          scale_y_continuous(name = "Reaction time (ms)",
                             breaks = seq(min, max, 200), 
                             limits = c(min, max)) +
          scale_fill_brewer(palette = "Dark2", name = "Response") +
          labs(title = paste("Participant ", i)) + 
          theme_minimal())
}


## Split-violin plots total
print(ggplot(resp_excl, aes(x=bright, y=duration, fill=correct))) +
        introdataviz::geom_split_violin(alpha = .4) +
        geom_boxplot(width = .2, alpha = .6, show.legend = FALSE) +
        stat_summary(fun.data = "mean_se", geom = "pointrange", show.legend = F, 
                      position = position_dodge(.175)) +
        scale_x_discrete(name = "Brightness") +
        scale_y_continuous(name = "Reaction time (ms)",
                           breaks = seq(min,max, 200),
                           limits = c(min, max)) +
        scale_fill_brewer(palette = "Dark2", name = "Response")+
        labs(title = "Split-violin Plots") + 
        theme_minimal()


write.csv(resp_excl, file.path(output_path, "resp_matrix_excl.csv", sep=""))
