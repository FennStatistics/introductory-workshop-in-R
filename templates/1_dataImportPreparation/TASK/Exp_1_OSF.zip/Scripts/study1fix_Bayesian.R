# Bayesian Hierarchical Modeling

# install.packages(c("coda","mvtnorm","devtools","loo","dagitty","shape"))
# devtools::install_github("rmcelreath/rethinking")

## load libraries
library(bayesplot)
library(bayestestR)
library(cmdstanr)
library(dplyr)
library(ggplot2)
library(ggpubr)
library(HDInterval)
library(pacman)
library(posterior)
library(reshape2)
library(rethinking)

# Set working directory to source file location
myDir = dirname(rstudioapi::getSourceEditorContext()$path)
setwd(myDir)


# Set relative paths
data_path <- "./../Data/"
output_path <- "./../Output/"


# Preparing data
## reading in data
raw_data <- read.csv(paste0(data_path, "resp_matrix_excl.csv"), header = TRUE)

## list of data for stan
data_list <- list(
  N = nrow(raw_data), 
  Ncntr = 2,
  Ninst = 3, 
  Nsubj = length(unique(raw_data$id)),
  rt = raw_data$duration / 1000,
  subj = as.numeric(factor(raw_data$id)), 
  cntr = as.numeric(factor(raw_data$bright, levels = c("rgb(255, 255, 255)", "rgb(15,15,15)"))),
  inst = as.numeric(factor(raw_data$instruction, levels = c("schnell", "akkurat", "schnell und so akkurat"))),
  stim = as.numeric(factor(raw_data$type, levels = c("word", "non_word"))),
  resp = as.numeric(factor(raw_data$response, levels = c("word", "non_word")))
)


# Fitting
## MCMC settings
seed <- 2025
Nwarmup <- 1000
Niter <- 2000
Nchains <- 4

## compiling model with CMDstan
comp_mod <- cmdstan_model("./study1fix_Bayesian.stan")

## define/generate initial values
init = function(chains=4) {
  L = list()
  for (c in 1:chains) {
    L[[c]] = list()
    
    L[[c]]$theta1_raw   = array(rnorm(data_list$Nsubj * 5, 0, 0.01), dim = c(data_list$Nsubj, 5))
    L[[c]]$theta2_raw   = array(rnorm(data_list$Nsubj * 5, 0, 0.01), dim = c(data_list$Nsubj, 5))
    L[[c]]$theta1_a_raw   = array(rnorm(data_list$Nsubj * 2, 0, 0.01), dim = c(data_list$Nsubj, 2))
    L[[c]]$theta2_a_raw   = array(rnorm(data_list$Nsubj * 2, 0, 0.01), dim = c(data_list$Nsubj, 2))
    L[[c]]$theta1_t0_raw   = array(rnorm(data_list$Nsubj * 2, 0, 0.01), dim = c(data_list$Nsubj, 2))
    L[[c]]$theta2_t0_raw   = array(rnorm(data_list$Nsubj * 2, 0, 0.01), dim = c(data_list$Nsubj, 2))
    L[[c]]$L_K_hi       = t(chol(rlkjcorr( 1 , 5 , eta=4 )))
    L[[c]]$L_K_lo       = t(chol(rlkjcorr( 1 , 5 , eta=4 )))
    L[[c]]$sigma2_H_hi  = runif(5)
    L[[c]]$sigma2_H_lo  = runif(5)
    L[[c]]$mu1_H_raw    = rnorm(5, 0, 0.2)
    L[[c]]$mu2_H_raw    = rnorm(5, 0, 0.2)
    L[[c]]$mu1_H_a_raw    = rnorm(2, 0, 0.2)
    L[[c]]$mu2_H_a_raw    = rnorm(2, 0, 0.2)
    L[[c]]$mu1_H_raw[5] = -2
    L[[c]]$mu2_H_raw[5] = -2
    L[[c]]$mu1_H_t0_raw    = c(-2, -2)
    L[[c]]$mu2_H_t0_raw    = c(-2, -2)

  }
  return (L)
}

## fit the model
fit <- comp_mod$sample(
  data = data_list,
  seed = seed,
  chains = Nchains,
  parallel_chains = 8,
  init = init(4),
  iter_warmup = Nwarmup,
  iter_sampling = Niter
)


# Saving
## save the fit object
saveRDS(fit, file = paste0(output_path, "fit_study1fix.rds"))
# fit <- readRDS(paste0(output_path, "fit_study1fix.rds"))

## save samples
samples <- fit$draws()
saveRDS(samples, file = paste0(output_path, "samples_study1fix.rds"))
# samples <- readRDS(paste0(output_path, "samples_study1fix.rds"))

## save summary
fit_summary <- fit$summary()
saveRDS(fit_summary, file = paste0(output_path, "summary_study1fix.rds"))
# fit_summary <- readRDS(paste0(output_path, "summary_study1fix.rds"))


# Get parameters of interest
variables(samples)
grouplevel_params <- posterior::subset_draws(samples, variable = c("mu1_H[1]", "mu1_H[2]", "mu1_H[3]", "mu1_H[4]", "mu1_H[5]",
                                                                   "mu2_H[1]", "mu2_H[2]", "mu2_H[3]", "mu2_H[4]", "mu2_H[5]",
                                                                   "mu3_H[1]", "mu3_H[2]", "mu3_H[3]", "mu3_H[4]", "mu3_H[5]",
                                                                   "mu4_H[1]", "mu4_H[2]", "mu4_H[3]", "mu4_H[4]", "mu4_H[5]",
                                                                   "mu5_H[1]", "mu5_H[2]", "mu5_H[3]", "mu5_H[4]", "mu5_H[5]",
                                                                   "mu6_H[1]", "mu6_H[2]", "mu6_H[3]", "mu6_H[4]", "mu6_H[5]",
                                                                   "sigma2_H_hi[1]", "sigma2_H_hi[2]", "sigma2_H_hi[3]", "sigma2_H_hi[4]", "sigma2_H_hi[5]",
                                                                   "sigma2_H_lo[1]", "sigma2_H_lo[2]", "sigma2_H_lo[3]", "sigma2_H_lo[4]", "sigma2_H_lo[5]"))

grid <- expand.grid(x = 1:5, y = 1:5)
Correlation_hi <- posterior::subset_draws(samples, variable = paste0("L_K_hi[", grid$x, ",", grid$y, "]"))
Correlation_lo <- posterior::subset_draws(samples, variable = paste0("L_K_lo[", grid$x, ",", grid$y, "]"))

## check trace plot and density overlap of the chains
mcmc_trace(grouplevel_params)
mcmc_dens_overlay(grouplevel_params)


# Renaming variables
mu_params <- rename_variables(grouplevel_params, 
                              mu_fa_lo_alpha = "mu1_H[1]", mu_fa_lo_nu_nw= "mu1_H[2]", mu_fa_lo_nu_rw=  "mu1_H[3]",
                              mu_fa_lo_omega = "mu1_H[4]", mu_fa_lo_tau =  "mu1_H[5]",
                              mu_fa_hi_alpha = "mu2_H[1]", mu_fa_hi_nu_nw= "mu2_H[2]", mu_fa_hi_nu_rw=  "mu2_H[3]",
                              mu_fa_hi_omega = "mu2_H[4]", mu_fa_hi_tau =  "mu2_H[5]",
                              mu_ac_lo_alpha = "mu3_H[1]", mu_ac_lo_nu_nw= "mu3_H[2]", mu_ac_lo_nu_rw=  "mu3_H[3]",
                              mu_ac_lo_omega = "mu3_H[4]", mu_ac_lo_tau =  "mu3_H[5]",
                              mu_ac_hi_alpha = "mu4_H[1]", mu_ac_hi_nu_nw= "mu4_H[2]", mu_ac_hi_nu_rw=  "mu4_H[3]",
                              mu_ac_hi_omega = "mu4_H[4]", mu_ac_hi_tau =  "mu4_H[5]",
                              mu_bo_lo_alpha = "mu5_H[1]", mu_bo_lo_nu_nw= "mu5_H[2]", mu_bo_lo_nu_rw=  "mu5_H[3]",
                              mu_bo_lo_omega = "mu5_H[4]", mu_bo_lo_tau =  "mu5_H[5]",
                              mu_bo_hi_alpha = "mu6_H[1]", mu_bo_hi_nu_nw= "mu6_H[2]", mu_bo_hi_nu_rw=  "mu6_H[3]",
                              mu_bo_hi_omega = "mu6_H[4]", mu_bo_hi_tau =  "mu6_H[5]")

sigma_params <- rename_variables(grouplevel_params,
                                 sigma2_hi_alpha = "sigma2_H_hi[1]", sigma2_hi_nw_nu = "sigma2_H_hi[2]", 
                                 sigma2_hi_rw_nu = "sigma2_H_hi[3]", sigma2_hi_omega = "sigma2_H_hi[4]", 
                                 sigma2_hi_tau = "sigma2_H_hi[5]",
                                 sigma2_lo_alpha = "sigma2_H_lo[1]", sigma2_lo_nw_nu = "sigma2_H_lo[2]", 
                                 sigma2_lo_rw_nu = "sigma2_H_lo[3]", sigma2_lo_omega = "sigma2_H_lo[4]", 
                                 sigma2_lo_tau = "sigma2_H_lo[5]")

mu_params_df <- as_draws_df(mu_params)
sigma_params_df <- as_draws_df(sigma_params)

Correlation_hi_df <- as_draws_df(Correlation_hi)
Correlation_lo_df <- as_draws_df(Correlation_lo)


# Calculate mean parameter on original scale
integrand <- function(x, mu, var) {
  tmp <- x - ifelse(is.infinite(log1p(exp(x))), x, log1p(exp(x))) + 0 - 0.5*log(2*pi*var)
  res <- tmp - (x-mu)^2/(2*var)
  return(exp(res))
}
vectorized_integrate <- Vectorize(function(mu, var) {
  integrate(integrand, lower = -Inf, upper = Inf, mu = mu, var = var)$value
})

mu_a_fa_hi <- exp(mu_params_df$mu_fa_hi_alpha + ((0.5836541^2+0.3369728^2)*sigma_params_df$sigma2_hi_alpha))
mu_a_ac_hi <- exp(mu_params_df$mu_ac_hi_alpha + ((0.5836541^2+0.3369728^2)*sigma_params_df$sigma2_hi_alpha))
mu_a_bo_hi <- exp(mu_params_df$mu_bo_hi_alpha + ((0.5836541^2+0.3369728^2)*sigma_params_df$sigma2_hi_alpha))
mu_a_fa_lo <- exp(mu_params_df$mu_fa_lo_alpha + ((0.5836541^2+0.3369728^2)*sigma_params_df$sigma2_lo_alpha))
mu_a_ac_lo <- exp(mu_params_df$mu_ac_lo_alpha + ((0.5836541^2+0.3369728^2)*sigma_params_df$sigma2_lo_alpha))
mu_a_bo_lo <- exp(mu_params_df$mu_bo_lo_alpha + ((0.5836541^2+0.3369728^2)*sigma_params_df$sigma2_lo_alpha))

mu_v_fa_hi_nw <- mu_params_df$mu_fa_hi_nu_nw
mu_v_ac_hi_nw <- mu_params_df$mu_ac_hi_nu_nw
mu_v_bo_hi_nw <- mu_params_df$mu_bo_hi_nu_nw
mu_v_fa_hi_rw <- mu_params_df$mu_fa_hi_nu_rw
mu_v_ac_hi_rw <- mu_params_df$mu_ac_hi_nu_rw
mu_v_bo_hi_rw <- mu_params_df$mu_bo_hi_nu_rw

mu_v_fa_lo_nw <- mu_params_df$mu_fa_lo_nu_nw
mu_v_ac_lo_nw <- mu_params_df$mu_ac_lo_nu_nw
mu_v_bo_lo_nw <- mu_params_df$mu_bo_lo_nu_nw
mu_v_fa_lo_rw <- mu_params_df$mu_fa_lo_nu_rw
mu_v_ac_lo_rw <- mu_params_df$mu_ac_lo_nu_rw
mu_v_bo_lo_rw <- mu_params_df$mu_bo_lo_nu_rw

var_hi <- (0.14761630^2+0.08522633^2)*sigma_params_df$sigma2_hi_omega
var_lo <- (0.14761630^2+0.08522633^2)*sigma_params_df$sigma2_lo_omega
mu_w_fa_hi <- vectorized_integrate(mu = mu_params_df$mu_fa_hi_omega, var = var_hi)
mu_w_ac_hi <- vectorized_integrate(mu = mu_params_df$mu_ac_hi_omega, var = var_hi)
mu_w_bo_hi <- vectorized_integrate(mu = mu_params_df$mu_bo_hi_omega, var = var_hi)
mu_w_fa_lo <- vectorized_integrate(mu = mu_params_df$mu_fa_lo_omega, var = var_lo)
mu_w_ac_lo <- vectorized_integrate(mu = mu_params_df$mu_ac_lo_omega, var = var_lo)
mu_w_bo_lo <- vectorized_integrate(mu = mu_params_df$mu_bo_lo_omega, var = var_lo)

mu_t0_fa_hi <- exp(mu_params_df$mu_fa_hi_tau + ((0.2594232^2+0.1497780^2)*sigma_params_df$sigma2_hi_tau))
mu_t0_ac_hi <- exp(mu_params_df$mu_ac_hi_tau + ((0.2594232^2+0.1497780^2)*sigma_params_df$sigma2_hi_tau))
mu_t0_bo_hi <- exp(mu_params_df$mu_bo_hi_tau + ((0.2594232^2+0.1497780^2)*sigma_params_df$sigma2_hi_tau))
mu_t0_fa_lo <- exp(mu_params_df$mu_fa_lo_tau + ((0.2594232^2+0.1497780^2)*sigma_params_df$sigma2_lo_tau))
mu_t0_ac_lo <- exp(mu_params_df$mu_ac_lo_tau + ((0.2594232^2+0.1497780^2)*sigma_params_df$sigma2_lo_tau))
mu_t0_bo_lo <- exp(mu_params_df$mu_bo_lo_tau + ((0.2594232^2+0.1497780^2)*sigma_params_df$sigma2_lo_tau))


# Test HDIs
hdi(mu_a_fa_hi - mu_a_fa_lo)
hdi(mu_a_ac_hi - mu_a_ac_lo)
hdi(mu_a_bo_hi - mu_a_bo_lo)
hdi(mu_v_fa_hi_nw - mu_v_fa_lo_nw)
hdi(mu_v_fa_hi_rw - mu_v_fa_lo_rw)
hdi(mu_w_fa_hi - mu_w_fa_lo)
hdi(mu_t0_fa_hi - mu_t0_fa_lo)
hdi(mu_t0_ac_hi - mu_t0_ac_lo)
hdi(mu_t0_bo_hi - mu_t0_bo_lo)


# Correlations with t0
t0x_hi <- posterior::subset_draws(samples, variable = paste0("L_K_hi[", 5, ",", 1:5, "]"))
t0x_lo <- posterior::subset_draws(samples, variable = paste0("L_K_lo[", 5, ",", 1:5, "]"))

t0x_hi_df <- as_draws_df(t0x_hi)
t0x_lo_df <- as_draws_df(t0x_lo)

t0x_hi_df <- as.data.frame(t0x_hi_df[,c(1:4)])
t0x_lo_df <- as.data.frame(t0x_lo_df[,c(1:4)])

colnames(t0x_hi_df) <- colnames(t0x_lo_df) <- c("a", "v_nw", "v_rw", "w")

## long format
long_hi_df <- melt(t0x_hi_df, variable.name = "variable", value.name = "value")
long_lo_df <- melt(t0x_lo_df, variable.name = "variable", value.name = "value")

## HDIs
hdi_hi_df <- lapply(split(long_hi_df$value, long_hi_df$variable), function(x) {
  hdi_range <- hdi(x, credMass = 0.95)
  data.frame(lower = hdi_range[1], upper = hdi_range[2])
})
hdi_lo_df <- lapply(split(long_lo_df$value, long_lo_df$variable), function(x) {
  hdi_range <- hdi(x, credMass = 0.95)
  data.frame(lower = hdi_range[1], upper = hdi_range[2])
})
hdi_hi_df <- do.call(rbind, hdi_hi_df)
hdi_lo_df <- do.call(rbind, hdi_lo_df)
hdi_hi_df$variable <- rownames(hdi_hi_df)
hdi_lo_df$variable <- rownames(hdi_lo_df)
rownames(hdi_hi_df) <- rownames(hdi_lo_df) <- NULL

## density value per variable
density_hi_list <- lapply(split(long_hi_df$value, long_hi_df$variable), density)
density_lo_list <- lapply(split(long_lo_df$value, long_lo_df$variable), density)

density_hi_df <- do.call(rbind, lapply(names(density_hi_list), function(var) {
  d <- density_hi_list[[var]]
  data.frame(x = d$x, y = d$y, variable = var)
}))
density_lo_df <- do.call(rbind, lapply(names(density_lo_list), function(var) {
  d <- density_lo_list[[var]]
  data.frame(x = d$x, y = d$y, variable = var)
}))

hdi_hi_fill_df <- do.call(rbind, lapply(names(density_hi_list), function(var) {
  d <- density_hi_list[[var]]
  hdi_vals <- hdi_hi_df[hdi_hi_df$variable == var, ]
  idx <- d$x >= hdi_vals$lower & d$x <= hdi_vals$upper
  data.frame(x = d$x[idx], y = d$y[idx], variable = var)
}))
hdi_lo_fill_df <- do.call(rbind, lapply(names(density_lo_list), function(var) {
  d <- density_lo_list[[var]]
  hdi_vals <- hdi_lo_df[hdi_lo_df$variable == var, ]
  idx <- d$x >= hdi_vals$lower & d$x <= hdi_vals$upper
  data.frame(x = d$x[idx], y = d$y[idx], variable = var)
}))

## plot
p1 <- ggplot() +
  geom_ribbon(data = hdi_hi_fill_df, aes(x = x, ymin = 0, ymax = y, fill = variable), alpha = 0.3) +
  geom_line(data = density_hi_df, aes(x = x, y = y, color = variable), size = 1) +
  geom_vline(xintercept = 0.0, color = "black", linewidth = 0.5) +  # <--- HIER
  theme_minimal() +
  labs(title = "High contrast condition",
       x = "Correlation",
       y = "Density") +
  scale_fill_discrete(name = "Parameter", labels = c("a" = "a", "v_rw" = "v_words", "v_nw" = "v_non-words", "w" = "zr")) +
  scale_color_discrete(name = "Parameter", labels = c("a" = "a", "v_rw" = "v_words", "v_nw" = "v_non-words", "w" = "zr"))

p2 <- ggplot() +
  geom_ribbon(data = hdi_lo_fill_df, aes(x = x, ymin = 0, ymax = y, fill = variable), alpha = 0.3) +
  geom_line(data = density_lo_df, aes(x = x, y = y, color = variable), size = 1) +
  geom_vline(xintercept = 0.0, color = "black", linewidth = 0.5) +  # <--- HIER
  theme_minimal() +
  labs(title = "Low contrast condition",
       x = "Correlation",
       y = "Density") +
  scale_fill_discrete(name = "Parameter", labels = c("a" = "a", "v_rw" = "v_words", "v_nw" = "v_non-words", "w" = "zr")) +
  scale_color_discrete(name = "Parameter", labels = c("a" = "a", "v_rw" = "v_words", "v_nw" = "v_non-words", "w" = "zr"))

combined_plot <- ggarrange(
  p1, p2,
  ncol = 2, nrow = 1,
  common.legend = TRUE,
  legend = "bottom"
)


# Parameter summary (median and HDI)
hdi(mu_a_fa_hi)
hdi(mu_a_fa_lo)
median(mu_a_fa_hi)
median(mu_a_fa_lo)

hdi(mu_a_ac_hi)
hdi(mu_a_ac_lo)
median(mu_a_ac_hi)
median(mu_a_ac_lo)

hdi(mu_a_bo_hi)
hdi(mu_a_bo_lo)
median(mu_a_bo_hi)
median(mu_a_bo_lo)

hdi(mu_v_fa_hi_nw)
hdi(mu_v_fa_lo_nw)
median(mu_v_fa_hi_nw)
median(mu_v_fa_lo_nw)

hdi(mu_v_fa_hi_rw)
hdi(mu_v_fa_lo_rw)
median(mu_v_fa_hi_rw)
median(mu_v_fa_lo_rw)

hdi(mu_w_fa_hi)
hdi(mu_w_fa_lo)
median(mu_w_fa_hi)
median(mu_w_fa_lo)

hdi(mu_t0_fa_hi)
hdi(mu_t0_fa_lo)
median(mu_t0_fa_hi)
median(mu_t0_fa_lo)

hdi(mu_t0_ac_hi)
hdi(mu_t0_ac_lo)
median(mu_t0_ac_hi)
median(mu_t0_ac_lo)

hdi(mu_t0_bo_hi)
hdi(mu_t0_bo_lo)
median(mu_t0_bo_hi)
median(mu_t0_bo_lo)
