##################################################
#### Descriptives, SIA Non-Decision Time #########
##################################################
# Loading Data -----------------------------------------------------------------
# Loading packages
require(pacman)
p_load('tidyverse', 'xlsx', 'psych', 'data.table', 'plyr', 'jsonlite', 'multiplex', 'rprojroot', 'lsr', 'data.table', 'scales', 'stats', 'rstatix', 'jtools', 'ggpubr')
options(scipen=999)


## Set working directory to source file location
myDir = dirname(rstudioapi::getSourceEditorContext()$path)
setwd(myDir)
output_path <- "../Output/"

## Reading in data
### response matrix
resp <- read.csv(paste0(output_path, "resp_matrix_excl.csv", sep=""), header=TRUE)
resp <- resp[,-1]

resp$correct <- as.logical(resp$correct)
factors <- c("correctResponse", "bright", "response", "instruction")
resp[,factors] <- lapply(resp[, factors], as.factor)

### participant matrix
par <- read.csv(paste0(output_path, "participant_matrix.csv", sep=""), header=TRUE)
par <- par[,-1]

#-------------------------------------------------------------------------------

# Descriptive statistics: participants -----------------------------------------
## total N
N <- nrow(par)

## participants' age
describe(par$alter)
ggplot(par, aes(x=alter, color=geschlecht)) +
  geom_histogram(binwidth=1, fill="white", position="dodge") +
  geom_vline(aes(xintercept=mean(alter, na.rm=T)), color="black", linetype="dashed")

## gender 
table(par$geschlecht)
prop.table(table(par$geschlecht))

## student & subjects
table(par$student)
prop.table(table(par$student))
table(par$studienfach)
prop.table(table(par$studienfach))

## visual impairment
table(par$sehschwaeche)
prop.table(table(par$sehschwaeche))

## corrected visual impairment (was inclusion criteria in case of visual impairment)
table(par$sehschwaeche_corrected)
prop.table(table(par$sehschwaeche_corrected)) 

## German as mother tongue (was inclusion criteria)
table(par$deutsch_muttersprache)
prop.table(table(par$deutsch_muttersprache))

## Counterbalancing of key:
table(par$keynonword) 
prop.table(table(par$keynonword, par$keyword)) 


# Descriptive statistics: behavioral data --------------------------------------
sum_stats_par_id <- resp %>% 
  dplyr::group_by(id) %>% 
  dplyr::summarise(
    trials = n(),
    mean_rt = mean(duration, na.rm=T),
    mean_rt_correct = mean(duration[correct==TRUE], na.rm=T),
    mean_acc = mean(correct, na.rm=T)
  ) %>% ungroup()

sum_stats_par_bright <- resp %>% 
  dplyr::group_by(bright) %>% 
  dplyr::summarise(
    trials = n(),
    mean_rt = mean(duration, na.rm=T),
    mean_rt_correct = mean(duration[correct==TRUE], na.rm=T),
    mean_acc = mean(correct, na.rm=T)
  ) %>% ungroup()


sum_stats_par_id_bright_instruction <- resp %>% 
  dplyr::group_by(id, bright, instruction) %>% 
  dplyr::summarise(
    trials = n(),
    mean_rt = mean(duration, na.rm = TRUE),
    mean_rt_correct = mean(duration[correct == TRUE], na.rm = TRUE),
    mean_acc = mean(correct, na.rm = TRUE)
  ) %>% ungroup()

sum_stats_per_id <- resp %>% 
  dplyr::group_by(id, bright, type, instruction) %>% 
  dplyr::summarise(
    trials = n(),
    mean_rt = mean(duration, na.rm = TRUE),
    mean_rt_correct = mean(duration[correct == TRUE], na.rm = TRUE),
    mean_acc = mean(correct, na.rm = TRUE)
  ) %>% ungroup()


sum_stats_bright_type <- aggregate(cbind(mean_acc = mean_acc, mean_rt = mean_rt) ~ bright + type + instruction, 
                                   data = sum_stats_per_id, 
                                   FUN = function(x) c(mean = mean(x, na.rm = TRUE), sd = sd(x, na.rm = TRUE)))


sum_stats_bright_type <- do.call(data.frame, sum_stats_bright_type)
colnames(sum_stats_bright_type) <- c("bright", "type","instruction", "mean_acc", "sd_acc", "mean_rt", "sd_rt")


sum_stats_long <- sum_stats_bright_type %>%
  pivot_longer(cols = c(mean_acc, mean_rt), names_to = "metric", values_to = "value") %>%
  pivot_longer(cols = c(sd_acc, sd_rt), names_to = "metric_sd", values_to = "sd") %>%
  filter((metric == "mean_acc" & metric_sd == "sd_acc") | (metric == "mean_rt" & metric_sd == "sd_rt")) %>%
  mutate(metric = recode(metric, "mean_acc" = "Mean Accuracy", "mean_rt" = "Mean Reaction Time"),
         bright = recode(bright, "rgb(15,15,15)" = "low", "rgb(255, 255, 255)" = "high"),
         type = factor(recode(type, 
                              "word" = "Word",
                              "non_word" = "Non-word"),
                       levels = c("Word", "Non-word")),
         instruction = recode(instruction, 
                              "akkurat" = "accurate",
                              "schnell" = "fast",
                              "schnell und so akkurat" = "fast & accurate"))


# Plot für Mean Accuracy
plot_accuracy <- ggplot(filter(sum_stats_long, metric == "Mean Accuracy"), aes(x = type, y = value, fill = bright)) +
  geom_bar(stat = "identity", position = position_dodge(width = 0.8), color = "black", width = 0.6) +
  geom_errorbar(aes(ymin = value - sd, ymax = value + sd),
                position = position_dodge(width = 0.8), width = 0.2, color = "black") +
  facet_wrap(~instruction, scales = "free_y") +
  scale_fill_manual(values = c("grey40", "grey70")) +
  coord_cartesian(ylim = c(0.65, 1)) +
  labs(y = "Mean Accuracy", x = "Contrast") +
  theme_apa(x.font.size = 18, y.font.size = 18, facet.title.size = 20) +
  theme(axis.text = element_text(size = 16), legend.position = "below", axis.title.x = element_blank())

# Plot für Mean Reaction Time
plot_rt <- ggplot(filter(sum_stats_long, metric == "Mean Reaction Time"), aes(x = type, y = value, fill = bright)) +
  geom_bar(stat = "identity", position = position_dodge(width = 0.8), color = "black", width = 0.6) +
  geom_errorbar(aes(ymin = value - sd, ymax = value + sd),
                position = position_dodge(width = 0.8), width = 0.2, color = "black") +
  facet_wrap(~instruction, scales = "free_y") +
  scale_fill_manual(values = c("grey40", "grey70")) +
  coord_cartesian(ylim = c(min(sum_stats_long$value[sum_stats_long$metric == "Mean Reaction Time"]) * 0.85, 
                           max(sum_stats_long$value[sum_stats_long$metric == "Mean Reaction Time"]) * 1.15)) + 
  labs(y = "Mean Reaction Time in ms", x = "Contrast") +
  theme_apa(x.font.size = 18, y.font.size = 18, facet.title.size = 20) +
  theme(axis.text = element_text(size = 16), legend.position = "none", axis.title.x = element_blank())


arranged_plots <- ggarrange(plot_rt, plot_accuracy, common.legend = TRUE, nrow=2, legend="bottom")
annotate_figure(
  arranged_plots,
  bottom = text_grob("Contrast", hjust = 2, vjust = -1.4, size = 18))




data_anova <- sum_stats_per_id %>%
  mutate(type = factor(type, levels = c("word", "non_word")),
         bright = factor(bright))


anova_results_rt <- data_anova %>%
  anova_test(dv = mean_rt, wid = id, within = c(bright, instruction, type), effect.size="pes") %>%
  get_anova_table(correction = "auto")
print(anova_results_rt)


anova_results_acc <- data_anova %>%
  anova_test(dv = mean_acc, wid = id, within = c(bright, instruction, type), effect.size="pes") %>%
  get_anova_table(correction = "auto")
print(anova_results_acc)


## Fast condition
# Mean rt and sd of low contrast condition
mean(sum_stats_par_id_bright_instruction$mean_rt[sum_stats_par_id_bright_instruction$bright=="rgb(15,15,15)"&sum_stats_par_id_bright_instruction$instruction=="schnell"], na.rm=T)
sd(sum_stats_par_id_bright_instruction$mean_rt[sum_stats_par_id_bright_instruction$bright=="rgb(15,15,15)"&sum_stats_par_id_bright_instruction$instruction=="schnell"], na.rm=T)

# Mean rt and sd of high contrast condition
mean(sum_stats_par_id_bright_instruction$mean_rt[sum_stats_par_id_bright_instruction$bright=="rgb(255, 255, 255)"&sum_stats_par_id_bright_instruction$instruction=="schnell"], na.rm=T)
sd(sum_stats_par_id_bright_instruction$mean_rt[sum_stats_par_id_bright_instruction$bright=="rgb(255, 255, 255)"&sum_stats_par_id_bright_instruction$instruction=="schnell"], na.rm=T)

# Mean accuracy and sd of low contrast condition
mean(sum_stats_par_id_bright_instruction$mean_acc[sum_stats_par_id_bright_instruction$bright=="rgb(15,15,15)"&sum_stats_par_id_bright_instruction$instruction=="schnell"], na.rm=T)
sd(sum_stats_par_id_bright_instruction$mean_acc[sum_stats_par_id_bright_instruction$bright=="rgb(15,15,15)"&sum_stats_par_id_bright_instruction$instruction=="schnell"], na.rm=T)

# Mean accuracy and sd of high contrast condition
mean(sum_stats_par_id_bright$mean_acc[sum_stats_par_id_bright$bright=="rgb(255, 255, 255)"&sum_stats_par_id_bright_instruction$instruction=="schnell"], na.rm=T)
sd(sum_stats_par_id_bright$mean_acc[sum_stats_par_id_bright$bright=="rgb(255, 255, 255)"&sum_stats_par_id_bright_instruction$instruction=="schnell"], na.rm=T)


## Accurate condition
# Mean rt and sd of low contrast condition
mean(sum_stats_par_id_bright_instruction$mean_rt[sum_stats_par_id_bright_instruction$bright=="rgb(15,15,15)"&sum_stats_par_id_bright_instruction$instruction=="akkurat"], na.rm=T)
sd(sum_stats_par_id_bright_instruction$mean_rt[sum_stats_par_id_bright_instruction$bright=="rgb(15,15,15)"&sum_stats_par_id_bright_instruction$instruction=="akkurat"], na.rm=T)

# Mean rt and sd of high contrast condition
mean(sum_stats_par_id_bright_instruction$mean_rt[sum_stats_par_id_bright_instruction$bright=="rgb(255, 255, 255)"&sum_stats_par_id_bright_instruction$instruction=="akkurat"], na.rm=T)
sd(sum_stats_par_id_bright_instruction$mean_rt[sum_stats_par_id_bright_instruction$bright=="rgb(255, 255, 255)"&sum_stats_par_id_bright_instruction$instruction=="akkurat"], na.rm=T)

# Mean accuracy and sd of low contrast condition
mean(sum_stats_par_id_bright_instruction$mean_acc[sum_stats_par_id_bright_instruction$bright=="rgb(15,15,15)"&sum_stats_par_id_bright_instruction$instruction=="akkurat"], na.rm=T)
sd(sum_stats_par_id_bright_instruction$mean_acc[sum_stats_par_id_bright_instruction$bright=="rgb(15,15,15)"&sum_stats_par_id_bright_instruction$instruction=="akkurat"], na.rm=T)

# Mean accuracy and sd of high contrast condition
mean(sum_stats_par_id_bright$mean_acc[sum_stats_par_id_bright$bright=="rgb(255, 255, 255)"&sum_stats_par_id_bright_instruction$instruction=="akkurat"], na.rm=T)
sd(sum_stats_par_id_bright$mean_acc[sum_stats_par_id_bright$bright=="rgb(255, 255, 255)"&sum_stats_par_id_bright_instruction$instruction=="akkurat"], na.rm=T)


## Fast and accurate condition
# Mean rt and sd of low contrast condition
mean(sum_stats_par_id_bright_instruction$mean_rt[sum_stats_par_id_bright_instruction$bright=="rgb(15,15,15)"&sum_stats_par_id_bright_instruction$instruction=="schnell und so akkurat"], na.rm=T)
sd(sum_stats_par_id_bright_instruction$mean_rt[sum_stats_par_id_bright_instruction$bright=="rgb(15,15,15)"&sum_stats_par_id_bright_instruction$instruction=="schnell und so akkurat"], na.rm=T)

# Mean rt and sd of high contrast condition
mean(sum_stats_par_id_bright_instruction$mean_rt[sum_stats_par_id_bright_instruction$bright=="rgb(255, 255, 255)"&sum_stats_par_id_bright_instruction$instruction=="schnell und so akkurat"], na.rm=T)
sd(sum_stats_par_id_bright_instruction$mean_rt[sum_stats_par_id_bright_instruction$bright=="rgb(255, 255, 255)"&sum_stats_par_id_bright_instruction$instruction=="schnell und so akkurat"], na.rm=T)

# Mean accuracy and sd of low contrast condition
mean(sum_stats_par_id_bright_instruction$mean_acc[sum_stats_par_id_bright_instruction$bright=="rgb(15,15,15)"&sum_stats_par_id_bright_instruction$instruction=="schnell und so akkurat"], na.rm=T)
sd(sum_stats_par_id_bright_instruction$mean_acc[sum_stats_par_id_bright_instruction$bright=="rgb(15,15,15)"&sum_stats_par_id_bright_instruction$instruction=="schnell und so akkurat"], na.rm=T)

# Mean accuracy and sd of high contrast condition
mean(sum_stats_par_id_bright_instruction$mean_acc[sum_stats_par_id_bright_instruction$bright=="rgb(255, 255, 255)"&sum_stats_par_id_bright_instruction$instruction=="schnell und so akkurat"], na.rm=T)
sd(sum_stats_par_id_bright_instruction$mean_acc[sum_stats_par_id_bright_instruction$bright=="rgb(255, 255, 255)"&sum_stats_par_id_bright_instruction$instruction=="schnell und so akkurat"], na.rm=T)


# ANOVA for RT 
aov_rt <- sum_stats_par_id_bright_instruction %>% anova_test(dv = mean_rt, wid = id, within = c(bright, instruction), effect.size="pes")
get_anova_table(aov_rt, correction = "auto")

posthoc_rt <- sum_stats_par_id_bright_instruction %>%
  group_by(instruction) %>% 
  pairwise_t_test(
    mean_rt ~ bright, 
    paired = TRUE,
    detailed = TRUE)

ggplot(sum_stats_par_id_bright_instruction, aes(x = instruction, y = mean_rt, fill = bright)) +
  geom_bar(stat = "identity", position = position_dodge())


# ANOVA for Accuracy
aov_acc <- sum_stats_par_id_bright_instruction %>% anova_test(dv = mean_acc, wid = id, within = c(bright, instruction), effect.size="pes")
get_anova_table(aov_acc, correction = "auto")

posthoc_acc <- sum_stats_par_id_bright_instruction %>%
  group_by(instruction) %>% 
  pairwise_t_test(
    mean_acc ~ bright, 
    paired = TRUE,
    detailed = TRUE)

ggplot(sum_stats_par_id_bright_instruction, aes(x = instruction, y = mean_acc, fill = bright)) +
  geom_bar(stat = "identity", position = position_dodge())




# Behavioral data over time ----------------------------------------------------

# Summary statistics for each block and instruction
resp_summary <- resp %>%
  dplyr::group_by(id, outer_counter, instruction) %>%
  dplyr::summarise(
    mean_rt = mean(duration, na.rm = TRUE),
    accuracy = mean(correct, na.rm = TRUE)
  ) %>%
  ungroup()

ggplot(resp_summary, aes(x = outer_counter, y = mean_rt, color = instruction)) +
  stat_summary(fun = mean, geom = "line", size = 1) +  # Mean RT per block across participants
  stat_summary(fun = mean, geom = "point") +  # Mean RT points
  labs(title = "Mean Reaction Time Across Blocks (Per Participant)",
       x = "Block (outer_counter)",
       y = "Mean Reaction Time (ms)",
       color = "Instruction") +
  theme_minimal()

ggplot(resp_summary, aes(x = outer_counter, y = accuracy, color = instruction)) +
  stat_summary(fun = mean, geom = "line", size = 1) +  # Mean accuracy per block across participants
  stat_summary(fun = mean, geom = "point") +  # Mean accuracy points
  labs(title = "Accuracy Across Blocks (Per Participant)",
       x = "Block (outer_counter)",
       y = "Proportion Correct",
       color = "Instruction") +
  theme_minimal()


