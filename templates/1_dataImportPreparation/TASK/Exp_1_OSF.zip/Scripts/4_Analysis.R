##################################################
#### Analyses, SIA Non-Decision Time #############
##################################################
# Loading Data -----------------------------------------------------------------
# Loading packages
require(pacman)
p_load('tidyverse', 'xlsx', 'psych', 'data.table', 'plyr', 'jsonlite', 'multiplex', 'rprojroot', 'lsr', 'data.table', 'scales')
options(scipen=999)


## Set working directory to source file location
myDir = dirname(rstudioapi::getSourceEditorContext()$path)
setwd(myDir)
output_path <- "../Output/"

## Reading in data
### response matrix
resp <- read.csv(paste0(output_path, "resp_matrix_excl.csv", sep=""), header=TRUE)
resp <- resp[,-1]

resp$correct <- as.logical(resp$correct)
factors <- c("correctResponse", "bright", "response", "instruction")
resp[,factors] <- lapply(resp[, factors], as.factor)

resp$instruction <- factor(resp$instruction, 
                           levels=c("akkurat", "schnell", "schnell und so akkurat"),
                           labels=c("a", "f", "fanda"))

resp$contrast <- factor(resp$bright, 
                        levels = c("rgb(255, 255, 255)", "rgb(15,15,15)"),
                        labels = c("high", "low"))
#-------------------------------------------------------------------------------

# Diffusion Modeling ----------------------------------------------------------
## Prepare individual datasets for Diffusion Modeling
resp_dif <- resp %>% 
  select(id, contrast, response, correctResponse, duration, instruction, correct) %>% 
  dplyr::rename(RESPONSE = response,
                TIME = duration,
                word_type = correctResponse) %>% 
  dplyr::mutate(RESPONSE=recode(RESPONSE,
                                "word" = 1,
                                "non_word" = 0)) # response coding

resp_dif$RESPONSE <- as.factor(resp_dif$RESPONSE)
resp_dif$TIME <- resp_dif$TIME/1000

resp_dif %>% 
  group_by(id) %>% 
  dplyr::group_walk(~ write.table(.x, file=paste0("../Data/fast-dm/participant",.y$id, ".txt"), sep="\t", quote = F))


txtFiles <- list.files(path = "../Data/fast-dm", pattern = "[[:digit:]].txt", full.names = FALSE)

for(i in 1:length(txtFiles)){
  tmpFile <- read.delim(file = paste0("../Data/fast-dm/",txtFiles[i]), header = TRUE)
  colnames(tmpFile) <- paste0("#", colnames(tmpFile))
  write.table(x = tmpFile, file = paste0("../Data/fast-dm/", txtFiles[i]), quote = FALSE, row.names = FALSE, sep="\t")
}


## Creating control file "experiment" [needed for fast-dm]
### Settings for modeling
method <- "ml"    #choose from ml, ks or cs
precision <- 5   #choose between 2 and 5
df_param <- data.frame(name=c("d", "zr", "szr", "sv", "st0"), logic=rep(FALSE,5))
df_depend <- data.frame(name=c("v", "a", "zr", "t0", "sv", "szr", "st0"), logic=rep(FALSE, 7), depends = rep(NA))

#### set to 0: if TRUE = set to 0, if zr = TRUE => zr = 0.5:
df_param$logic[df_param$name=="d"] <- TRUE
df_param$logic[df_param$name=="zr"] <- FALSE
df_param$logic[df_param$name=="szr"] <- FALSE
df_param$logic[df_param$name=="sv"] <- FALSE
df_param$logic[df_param$name=="st0"] <- FALSE

### set depends: if TRUE = param depends
df_depend$logic[df_depend$name=="v"] <- TRUE
df_depend$logic[df_depend$name=="a"] <- TRUE
df_depend$logic[df_depend$name=="zr"] <- TRUE
df_depend$logic[df_depend$name=="t0"] <- TRUE
df_depend$logic[df_depend$name=="sv"] <- FALSE
df_depend$logic[df_depend$name=="szr"] <- FALSE
df_depend$logic[df_depend$name=="st0"] <- FALSE

### set depends on:  
df_depend$depends[df_depend$name=="v"] <- paste0(colnames(resp_dif[4])," ", colnames(resp_dif[2]))
df_depend$depends[df_depend$name=="a"] <- paste0(colnames(resp_dif[6]), " ", colnames(resp_dif[2]))
df_depend$depends[df_depend$name=="zr"] <- paste0(colnames(resp_dif[2]))
df_depend$depends[df_depend$name=="t0"] <- paste0(colnames(resp_dif[2])," ", colnames(resp_dif[6]))
df_depend$depends[df_depend$name=="sv"] <- NA
df_depend$depends[df_depend$name=="szr"] <- NA
df_depend$depends[df_depend$name=="st0"] <- NA


format <- paste0(colnames(resp_dif[2])," ", colnames(resp_dif[3])," ", colnames(resp_dif[4]), " ", colnames(resp_dif[5]), " ", colnames(resp_dif[6]), " ", colnames(resp_dif[7]))   #specify the ordering of variables in the dataset here
input <- "participant*.txt"       #names of input files, here participant1.txt, participant2.txt etc.
output <- "all_participants_M3a.dat"  #output file name, Attention: There must not be a file with the same name in the folder


#---------- execute to create file called experiment.ctl -----------------------
params <- str_sub(capture.output(for(i in unique(df_param$name)){
  if(df_param$logic[df_param$name==i] == TRUE){
    if(i=="zr"){
      print(paste0("set ", df_param$name[df_param$name==i]," 0.5"), quote=F)
    }else{
      print(paste0("set ", df_param$name[df_param$name==i]," 0"), quote=F)
    }  } }), start=5)

depends <- str_sub(capture.output(for(i in unique(df_depend$name)){
  if(df_depend$logic[df_depend$name==i] == TRUE){
    print(paste0("depends ", df_depend$name[df_depend$name==i]," ", df_depend$depends[df_depend$name==i]), quote=F)
  } }), start=5)


fileConn <- file("../Data/fast-dm/experiment.ctl")
writeLines(c(paste0("method ", method), 
             paste0("precision ", precision),
             params,
             depends,
             paste0("format ", format),
             paste0("load ", input),
             paste0("log ", output)), fileConn)
close(fileConn)
# ------------- experiment.ctl created -----------------------------------------

#Running fast-dm (folder with individual data files also needs to have the fast-dm.exe file + ctl-file called "experiment")
system(paste0("cmd.exe /c", " cd ",find_rstudio_root_file(),"/Data/fast-dm", "&& fast-dm.exe"))


write.csv(resp_dif, file.path(output_path, "resp_dif.csv", sep=""))
